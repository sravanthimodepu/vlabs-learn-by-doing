This module is NOT for direct use. 
It is part of the Page Course Format implementation.